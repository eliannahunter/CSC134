// #6 is not working. It keeps saying to place ;, but I have and I even added an int and its still not working. Come back**
// #9 is not working. I fixed all of the errors, but redefinition of "c" keeps popping up. Come back**
// #13 & 14 is not working. I continue to change 'v' but it isn't working still. Come back** 
// #15 is not working.